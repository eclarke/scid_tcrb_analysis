##' ggbeeswarm
##' 
##' @name ggbeeswarm-package
##' @docType package
##' @import proto
##' 
NULL